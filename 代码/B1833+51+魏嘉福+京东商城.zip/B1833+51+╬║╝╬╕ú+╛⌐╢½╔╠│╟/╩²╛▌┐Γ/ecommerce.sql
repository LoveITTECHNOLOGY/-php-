-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2020 年 06 月 23 日 01:39
-- 服务器版本: 5.5.8
-- PHP 版本: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `ecommerce`
--

-- --------------------------------------------------------

--
-- 表的结构 `admin_info`
--

CREATE TABLE IF NOT EXISTS `admin_info` (
  `admin_id` int(10) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(100) NOT NULL,
  `admin_email` varchar(300) NOT NULL,
  `admin_password` varchar(300) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `admin_info`
--

INSERT INTO `admin_info` (`admin_id`, `admin_name`, `admin_email`, `admin_password`) VALUES
(1, 'admin', 'admin@gmail.com', '25f9e794323b453885f5181f1b624d0b'),
(3, '12', '123', '343'),
(4, '123', '123', '123');

-- --------------------------------------------------------

--
-- 表的结构 `brands`
--

CREATE TABLE IF NOT EXISTS `brands` (
  `brand_id` int(100) NOT NULL AUTO_INCREMENT,
  `brand_title` text NOT NULL,
  PRIMARY KEY (`brand_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_title`) VALUES
(1, '惠普\r\n'),
(2, '三星'),
(3, '苹果'),
(4, '摩托罗拉'),
(5, 'LG'),
(6, '布牌');

-- --------------------------------------------------------

--
-- 表的结构 `cart`
--

CREATE TABLE IF NOT EXISTS `cart` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `p_id` int(10) NOT NULL,
  `ip_add` varchar(250) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `qty` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=64 ;

--
-- 转存表中的数据 `cart`
--

INSERT INTO `cart` (`id`, `p_id`, `ip_add`, `user_id`, `qty`) VALUES
(6, 26, '::1', 4, 1),
(9, 10, '::1', 7, 1),
(10, 11, '::1', 7, 1),
(11, 45, '::1', 7, 1),
(44, 5, '::1', 3, 0),
(46, 2, '::1', 3, 0),
(48, 72, '::1', 3, 0),
(49, 60, '::1', 8, 1),
(50, 61, '::1', 8, 1),
(51, 1, '::1', 8, 1),
(52, 5, '::1', 9, 1),
(53, 2, '::1', 14, 1),
(54, 3, '::1', 14, 1),
(55, 5, '::1', 14, 1),
(56, 1, '::1', 9, 1),
(57, 2, '::1', 9, 1),
(58, 72, '127.0.0.1', 36, 1),
(59, 3, '127.0.0.1', 50, 1),
(60, 1, '127.0.0.1', 51, 1),
(61, 65, '127.0.0.1', 51, 1),
(63, 72, '127.0.0.1', 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `cat_id` int(100) NOT NULL AUTO_INCREMENT,
  `cat_title` text NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- 转存表中的数据 `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(1, '电子产品'),
(2, '女装'),
(3, '男装'),
(4, '童装'),
(5, '家具类'),
(6, '家用电器'),
(7, '电子产品');

-- --------------------------------------------------------

--
-- 表的结构 `email_info`
--

CREATE TABLE IF NOT EXISTS `email_info` (
  `email_id` int(100) NOT NULL AUTO_INCREMENT,
  `email` text NOT NULL,
  PRIMARY KEY (`email_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- 转存表中的数据 `email_info`
--

INSERT INTO `email_info` (`email_id`, `email`) VALUES
(3, 'admin@gmail.com'),
(4, '78734751@gmail.com'),
(5, 'puneethreddy@gmail.com'),
(6, 'weijiafu599@gmail.com'),
(9, '18919002649@189.cn'),
(10, '123@189.cn'),
(11, 'weijia599@gmail.com');

-- --------------------------------------------------------

--
-- 表的结构 `logs`
--

CREATE TABLE IF NOT EXISTS `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) NOT NULL,
  `action` varchar(50) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 转存表中的数据 `logs`
--


-- --------------------------------------------------------

--
-- 表的结构 `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `trx_id` varchar(255) NOT NULL,
  `p_status` varchar(20) NOT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `product_id`, `qty`, `trx_id`, `p_status`) VALUES
(1, 12, 7, 1, '07M47684BS5725041', 'Completed'),
(2, 14, 2, 1, '07M47684BS5725041', 'Completed');

-- --------------------------------------------------------

--
-- 表的结构 `orders_info`
--

CREATE TABLE IF NOT EXISTS `orders_info` (
  `order_id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `f_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip` int(10) NOT NULL,
  `cardname` varchar(255) NOT NULL,
  `cardnumber` varchar(20) NOT NULL,
  `expdate` varchar(255) NOT NULL,
  `prod_count` int(15) DEFAULT NULL,
  `total_amt` int(15) DEFAULT NULL,
  `cvv` int(5) NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `orders_info`
--

INSERT INTO `orders_info` (`order_id`, `user_id`, `f_name`, `email`, `address`, `city`, `state`, `zip`, `cardname`, `cardnumber`, `expdate`, `prod_count`, `total_amt`, `cvv`) VALUES
(1, 12, '魏家福', '22222221@gmail.com', '甘肃省 兰州 城关区', '兰州', '定西', 75000, '农业', '123456788', '12/90', 3, 77000, 1234),
(2, 26, 'jiafu wei', '18919002649@189.cn', 'china', 'lanzhou', 'Gansu', 73000, '12', '12', '12', 1, 4579, 12),
(3, 49, 'jiafu wei', '123@189.cn', 'china', 'lanzhou', 'Gansu', 73000, '12', '123545', '1232', 1, 10000, 12),
(4, 75, 'jiafu wei', '1234@gmail.com', 'china', 'lanzhou', 'Gansu', 73000, '12', '123', '123', 2, 10500, 123);

-- --------------------------------------------------------

--
-- 表的结构 `order_products`
--

CREATE TABLE IF NOT EXISTS `order_products` (
  `order_pro_id` int(10) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(15) DEFAULT NULL,
  `amt` int(15) DEFAULT NULL,
  PRIMARY KEY (`order_pro_id`),
  KEY `order_products` (`order_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=95 ;

--
-- 转存表中的数据 `order_products`
--

INSERT INTO `order_products` (`order_pro_id`, `order_id`, `product_id`, `qty`, `amt`) VALUES
(73, 1, 1, 1, 5000),
(74, 1, 4, 2, 64000),
(75, 1, 8, 1, 40000),
(91, 2, 78, 1, 4579),
(92, 3, 5, 1, 10000),
(93, 4, 74, 1, 5500),
(94, 4, 1, 1, 5000);

-- --------------------------------------------------------

--
-- 表的结构 `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `product_id` int(100) NOT NULL AUTO_INCREMENT,
  `product_cat` int(100) NOT NULL,
  `product_brand` int(100) NOT NULL,
  `product_title` varchar(255) NOT NULL,
  `product_price` int(100) NOT NULL,
  `product_desc` text NOT NULL,
  `product_image` text NOT NULL,
  `product_keywords` text NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=85 ;

--
-- 转存表中的数据 `products`
--

INSERT INTO `products` (`product_id`, `product_cat`, `product_brand`, `product_title`, `product_price`, `product_desc`, `product_image`, `product_keywords`) VALUES
(1, 1, 2, '三星Galaxy S7 Edge', 5000, '三星Galaxy S7 Edge', 'product07.png', '三星移动电子'),
(2, 1, 3, 'iPhone 5S', 25000, 'iphone 5s', 'http___pluspng.com_img-png_iphone-hd-png-iphone-apple-png-file-550.png', '苹果手机'),
(3, 1, 3, 'iPad air 2', 30000, 'ipad苹果品牌', 'da4371ffa192a115f922b1c0dff88193.png', '苹果ipad平板电脑'),
(4, 1, 3, 'iPhone 6s', 32000, '苹果iPhone', 'http___pluspng.com_img-png_iphone-6s-png-iphone-6s-gold-64gb-1000.png', '苹果手机'),
(5, 1, 2, 'iPad 2', 10000, '三星ipad', 'iPad-air.png', 'ipad平板电脑三星'),
(6, 1, 1, '三星笔记本电脑r系列', 35000, '三星黑色组合笔记本电脑', 'laptop_PNG5939.png', '三星笔记本电脑'),
(7, 1, 1, '笔记本电脑馆', 50000, '笔记本电脑惠普馆', 'laptop_PNG5930.png', '笔记本电脑惠普馆'),
(8, 1, 4, '了索尼', 40000, '索尼手机', '530201353846AM_635_sony_xperia_z.png', '索尼手机'),
(9, 1, 3, '新iPhone', 12000, '苹果手机', 'iphone-hd-png-iphone-apple-png-file-550.png', '苹果手机'),
(10, 2, 6, '红色女士连衣裙', 1000, '女孩的红裙子', 'red dress.jpg', '红色礼服'),
(11, 2, 6, '蓝色波浪连衣裙', 1200, '蓝色连衣裙', 'images.jpg', '蓝色礼服布'),
(12, 2, 6, '女士休闲布', 1500, '女士休闲夏季两种颜色打褶', '7475-ladies-casual-dresses-summer-two-colors-pleated.jpg', '女孩礼服布休闲'),
(13, 2, 6, '春季秋季礼服', 1200, '女孩装', 'Spring-Autumn-Winter-Young-Ladies-Casual-Wool-Dress-Women-s-One-Piece-Dresse-Dating-Clothes-Medium.jpg_640x640.jpg', '女孩礼服'),
(14, 2, 6, '休闲服饰', 1400, '女孩礼服', 'download.jpg', '女士布女孩'),
(15, 2, 6, '正式外观', 1500, '女孩礼服', 'shutterstock_203611819.jpg', '女士们穿礼服的女孩'),
(16, 3, 6, '男士毛衣', 600, '2012冬季男士毛衣要好看', '2012-Winter-Sweater-for-Men-for-better-outlook.jpg', '黑色天鹅绒布冬天'),
(17, 3, 6, '绅士正式', 1000, '绅士的正式外观', 'gents-formal-250x250.jpg', '男士穿布'),
(19, 3, 6, '正式外套', 3000, 'ad', 'images (1).jpg', '西装外套绅士'),
(20, 3, 6, '男士毛衣', 1600, 'jg', 'Winter-fashion-men-burst-sweater.png', '毛衣绅士'),
(21, 3, 6, 'T恤', 800, '固态硬盘', 'IN-Mens-Apparel-Voodoo-Tiles-09._V333872612_.jpg', '正式T恤黑色'),
(22, 4, 6, '黄色T恤', 1300, '裤子黄色y恤', '1.0x0.jpg', '儿童黄色T恤'),
(23, 4, 6, '女孩的衣服', 1900, '小王', 'GirlsClothing_Widgets.jpg', '正式的孩子穿衣服'),
(24, 4, 6, '蓝色T恤', 700, 'g', 'images.jpg', '孩子们穿'),
(25, 4, 6, '黄色女孩连衣裙', 750, 'as', 'images (3).jpg', '黄色的孩子们的衣服'),
(27, 4, 6, '正式外观', 690, 'sd', 'image28.jpg', '正式的孩子们的着装'),
(32, 5, 0, '书架', 2500, '书架', 'furniture-book-shelf-250x250.jpg', '书架家具'),
(33, 6, 2, '冰箱', 35000, '冰箱', 'CT_WM_BTS-BTC-AppliancesHome_20150723.jpg', '三星冰箱'),
(34, 6, 4, '紧急灯', 1000, '紧急灯', 'emergency light.JPG', '紧急灯'),
(35, 6, 0, '吸尘器', 6000, '吸尘器', 'images (2).jpg', '吸尘器'),
(36, 6, 5, '铁', 1500, 'gj', 'iron.JPG', '铁'),
(37, 6, 5, 'LED电视', 20000, 'LED电视', 'images (4).jpg', 'LED电视'),
(38, 6, 4, '微波炉', 3500, '微波炉', 'images.jpg', '微波炉'),
(39, 6, 5, '搅拌机研磨机', 2500, '搅拌机研磨机', 'singer-mixer-grinder-mg-46-medium_4bfa018096c25dec7ba0af40662856ef.jpg', '搅拌机研磨机'),
(40, 2, 6, '正式的女孩打扮', 3000, '正式的女孩打扮', 'girl-walking.jpg', '正式的女孩打扮'),
(45, 1, 2, '三星Galaxy Note 3', 10000, '0', 'samsung_galaxy_note3_note3neo.JPG', '三星Galaxy Note 3'),
(46, 1, 2, '三星Galaxy Note 3', 10000, '三星Galaxy Note 3', 'samsung_galaxy_note3_note3neo.JPG', '三星Galaxy Note 3'),
(47, 4, 6, '笔记本电脑', 650, 'nbk', 'product01.png', '笔记本电脑'),
(48, 1, 7, '头戴式耳机', 250, '头戴式耳机', 'product05.png', '头戴式耳机'),
(49, 1, 7, '头戴式耳机', 250, '头戴式耳机', 'product05.png', '头戴式耳机'),
(50, 3, 6, '男童衬衫', 350, '男童衬衫', 'pm1.JPG', '男童衬衫'),
(51, 3, 6, '男童衬衫', 270, '男童衬衫', 'pm2.JPG', '男童衬衫'),
(52, 3, 6, '男童衬衫', 453, '男童衬衫', 'pm3.JPG', '男童衬衫'),
(53, 3, 6, '男童衬衫', 220, '男童衬衫', 'ms1.JPG', '男童衬衫'),
(54, 3, 6, '男童衬衫', 290, '男童衬衫', 'ms2.JPG', '男童衬衫'),
(55, 3, 6, '男童衬衫', 259, '男童衬衫', 'ms3.JPG', '男童衬衫'),
(56, 3, 6, '男童衬衫', 299, '男童衬衫', 'pm7.JPG', '男童衬衫'),
(57, 3, 6, '男童衬衫', 260, '男童衬衫', 'i3.JPG', '男童衬衫'),
(58, 3, 6, '男童衬衫', 350, '男童衬衫', 'pm9.JPG', '男童衬衫'),
(59, 3, 6, '男童衬衫', 855, '男童衬衫', 'a2.JPG', '男童衬衫'),
(60, 3, 6, '男童衬衫', 150, '男童衬衫', 'pm11.JPG', '男童衬衫'),
(61, 3, 6, '男童衬衫', 215, '男童衬衫', 'pm12.JPG', '男童衬衫'),
(62, 3, 6, '男童衬衫', 299, 'shirts', 'pm13.JPG', '男童衬衫'),
(63, 3, 6, '男童牛仔裤裤', 550, '男童牛仔裤裤', 'pt1.JPG', '男童牛仔裤裤'),
(64, 3, 6, '男童牛仔裤裤', 460, '男童牛仔裤裤', 'pt2.JPG', '男童牛仔裤裤'),
(65, 3, 6, '男童牛仔裤裤', 470, '男童牛仔裤裤', 'pt3.JPG', '男童牛仔裤裤'),
(66, 3, 6, '男童牛仔裤裤', 480, '男童牛仔裤裤', 'pt4.JPG', '男童牛仔裤裤'),
(67, 3, 6, '男童牛仔裤裤', 360, '男童牛仔裤裤', 'pt5.JPG', '男童牛仔裤裤'),
(68, 3, 6, '男童牛仔裤裤', 550, '男童牛仔裤裤', 'pt6.JPG', '男童牛仔裤裤'),
(69, 3, 6, '男童牛仔裤裤', 390, '男童牛仔裤裤', 'pt7.JPG', '男童牛仔裤裤'),
(70, 3, 6, '男童牛仔裤裤', 399, '男童牛仔裤裤', 'pt8.JPG', '男童牛仔裤裤'),
(71, 1, 2, '三星银河S7', 5000, '三星银河S', 'product07.png', '三星银河S'),
(72, 7, 2, '三星银河S', 3500, '三星银河S', 'product02.png', '三星银河S'),
(73, 7, 2, '三星耳机', 3500, '三星耳机', 'product05.png', '三星耳机电子产品小工具s'),
(74, 1, 1, 'HP i5笔记本电脑', 5500, 'HP i5笔记本电脑', 'product01.png', 'HP i5笔记本电脑'),
(75, 1, 1, 'HP i7笔记本电脑8GB内存', 5500, 'HP i7笔记本电脑8GB内存', 'product03.png', 'HP i7笔记本电脑8GB内存'),
(76, 1, 5, '索尼Note 6GB RAM', 4500, '索尼Note 6GB RAM', 'product04.png', '索尼note 6gb ram移动电子产品'),
(77, 1, 4, 'MSV笔记本电脑16GB内存NVIDEA图形', 5499, 'MSV笔记本电脑16GB内存', 'product06.png', 'MSV笔记本电脑16GB内存NVIDEA图形'),
(78, 1, 5, '戴尔笔记本电脑8GB内存英特尔整数图形', 4579, '戴尔笔记本电脑8GB内存英特尔整数图形', 'product08.png', '戴尔笔记本电脑8GB内存英特尔整数图形'),
(79, 7, 2, '具有3D像素的相机', 2569, '具有3D像素的相机', 'product09.png', '具有3D像素的相机'),
(80, 1, 1, '123', 12343, 'sdfhgh', 'iron.JPG', '123'),
(84, 0, 12345, '12345', 12345, '*犬瘟热34\r\n', 'product07.png', '');

-- --------------------------------------------------------

--
-- 表的结构 `user_info`
--

CREATE TABLE IF NOT EXISTS `user_info` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address1` varchar(300) NOT NULL,
  `address2` varchar(11) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=77 ;

--
-- 转存表中的数据 `user_info`
--

INSERT INTO `user_info` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address1`, `address2`) VALUES
(12, '魏', '小', '233451@gmail.com', 'qwer123478', '1891900264', '123456789', 'qwerr'),
(16, '魏', '小', 'venkey@gmail.com', '1234534', '9877654334', 'snhdgvajfehyfygv', 'asdjbhfkeur'),
(26, 'wei', 'jiafu', '18919002649@189.cn', 'qwer12341234', '1891900264', 'china', 'lanzhou'),
(27, 'jiafu', 'wei', 'weijiafu599@gmail.com', '1234', '1891900264', 'lanzhou', '美国'),
(28, 'jiafu', 'wei', 'weijiafu599@gmail.com', '1234', '1891900264', 'lanzhou', '美国'),
(30, 'jiafu', 'wei', 'weijiafu599@gmail.com', '1234', '1891900264', 'lanzhou', '美国'),
(49, 'wei', 'jiafu', '124@189.cn', 'qwer12341234', '1891900264', 'china', 'lanzhou'),
(71, 'jiafu', 'wei', 'weijia599@gmail.com', '1234', '1891900264', 'lanzhou', 'china'),
(74, 'jiafu', 'wei', 'weij99@gmail.com', '1234', '', '', ''),
(75, 'wei', 'jiafu', '1234@gmail.com', '@Qwer12341234', '1891900264', 'china', 'lanzhou'),
(76, 'jiafu', 'wei', 'weijiafu599@gmail.com', '1234', '', '', '');

--
-- 触发器 `user_info`
--
DROP TRIGGER IF EXISTS `after_user_info_insert`;
DELIMITER //
CREATE TRIGGER `after_user_info_insert` AFTER INSERT ON `user_info`
 FOR EACH ROW BEGIN 
INSERT INTO user_info_backup VALUES(new.user_id,new.first_name,new.last_name,new.email,new.password,new.mobile,new.address1,new.address2);
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- 表的结构 `user_info_backup`
--

CREATE TABLE IF NOT EXISTS `user_info_backup` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address1` varchar(300) NOT NULL,
  `address2` varchar(11) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=77 ;

--
-- 转存表中的数据 `user_info_backup`
--

INSERT INTO `user_info_backup` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address1`, `address2`) VALUES
(75, 'wei', 'jiafu', '1234@gmail.com', '@Qwer12341234', '1891900264', 'china', 'lanzhou'),
(76, 'jiafu', 'wei', 'weijiafu599@gmail.com', '1234', '', '', '');

--
-- 限制导出的表
--

--
-- 限制表 `orders_info`
--
ALTER TABLE `orders_info`
  ADD CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `user_info` (`user_id`);

--
-- 限制表 `order_products`
--
ALTER TABLE `order_products`
  ADD CONSTRAINT `order_products` FOREIGN KEY (`order_id`) REFERENCES `orders_info` (`order_id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);
