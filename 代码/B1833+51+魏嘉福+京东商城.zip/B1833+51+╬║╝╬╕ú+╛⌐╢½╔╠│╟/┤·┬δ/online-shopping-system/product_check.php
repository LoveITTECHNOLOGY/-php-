<?php

//开始连接数据库
$conn=mysql_connect("localhost","root","");
//开始查询数据库
mysql_select_db("ecommerce",$conn);
//开始将查询的内容设置成中文
mysql_query("set names 'UTF8'");
//开始传值
$product_brand=$_POST['product_brand'];
$product_title=$_POST['product_title'];
$product_price=$_POST['product_price'];
$product_desc=$_POST['product_desc'];
$product_image=$_POST['product_image'];

//开始插入内容
mysql_query("insert into products(product_brand,product_title,product_price,product_desc,product_image)
VALUES ('".$product_brand."','".$product_title."','".$product_price."','".$product_desc."','".$product_image."')");
//开始返回主页面
header("location:product1.php");
?>