<?php
/**
 * Created by PhpStorm.
 * User: administer
 * Date: 2020/3/19
 * Time: 14:46
 */
//开始连接数据库
$conn=mysql_connect("localhost","root","");
//开始连接数据库表
mysql_select_db("ecommerce",$conn);
//开始将内容转换为中文字符
mysql_query("set names UTF8");
$id=intval($_GET['id']);
$admin_name=$_POST['admin_name'];
$admin_email=$_POST['admin_email'];
$admin_password=$_POST['admin_password'];
$sql="update  admin_info set admin_name='$admin_name',admin_email='$admin_email',admin_password='$admin_password'
 where admin_id=".$id;
$r=mysql_query($sql);
if($r)
    echo "<script>alert('修改成功');
location.href='admin_manage.php';</script>";
?>
<html>
<meta charset="utf-8">
</html>