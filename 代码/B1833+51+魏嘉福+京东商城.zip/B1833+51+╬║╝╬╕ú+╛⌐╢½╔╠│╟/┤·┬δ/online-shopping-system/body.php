
   <div class="main main-raised">
        <div class="container mainn-raised" style="width:100%;">
  
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- 辨别 -->
   

    <!-- 写出图片切换效果 -->
    <div class="carousel-inner">

      <div class="item active">
        <img src="img/banner1.jpg" alt="Los Angeles" style="width:100%;">
        
      </div>

      <div class="item">
        <img src="img/banner1.jpg" style="width:100%;">
        
      </div>
    
      <div class="item">
        <img src="img/banner1.jpg" alt="New York" style="width:100%;">
        
      </div>
      <div class="item">
        <img src="img/banner3.JPG" alt="New York" style="width:100%;">
        
      </div>
      <div class="item">
        <img src="img/banner3.JPG" alt="New York" style="width:100%;">
        
      </div>
  
    </div>

    <!-- 进行左右控制 -->
    <a class="left carousel-control _26sdfg" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only" >以前</span>
    </a>
    <a class="right carousel-control _26sdfg" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">下一个</span>
    </a>
  </div>
</div>
     


		<!-- 选择 -->
		<div class="section mainn mainn-raised">
		
		
			<!-- 大的容器 -->
			<div class="container">
			
				<!-- 行-->
				<div class="row">
					<!-- 插入购物图片-->
					<div class="col-md-4 col-xs-6">
						<a href="product.php?p=78"><div class="shop">
							<div class="shop-img">
								<img src="./img/shop01.png" alt="">
							</div>
							<div class="shop-body">
								<h3>联想电脑<br>收藏</h3>
								<a href="product.php?p=78" class="cta-btn">马上购物<i class="fa fa-arrow-circle-right"></i></a>
							</div>
						</div></a>
					</div>
					<!-- 购物 -->

					<!-- 购物-->
					<div class="col-md-4 col-xs-6">
						<a href="product.php?p=72"><div class="shop">
							<div class="shop-img">
								<img src="./img/shop03.png" alt="">
							</div>
							<div class="shop-body">
								<h3>配饰<br>收藏</h3>
								<a href="product.php?p=72" class="cta-btn">马上购物<i class="fa fa-arrow-circle-right"></i></a>
							</div>
						</div></a>
					</div>
					<!-- /shop -->

					<!-- shop -->
					<div class="col-md-4 col-xs-6">
						<a href="product.php?p=79"><div class="shop">
							<div class="shop-img">
								<img src="./img/shop02.png" alt="">
							</div>
							<div class="shop-body">
								<h3>相机<br>收藏</h3>
								<a href="product.php?p=79" class="cta-btn">马上购物<i class="fa fa-arrow-circle-right"></i></a>
							</div>
                            </div></a>
					</div>
					<!-- /购物 -->
				</div>
				<!-- /行-->
			</div>
			<!-- /容器 -->
		</div>
		<!-- /选择 -->
		  
		

		<!-- 选择 -->
		<div class="section">
			<!-- 大容器 -->
			<div class="container">
				<!-- 行 -->
				<div class="row">

					<!-- 选择标题-->
					<div class="col-md-12">
						<div class="section-title">
							<h3 class="title">新品上架</h3>
							<div class="section-nav">
								<ul class="section-tab-nav tab-nav">
									<li class="active"><a data-toggle="tab" href="#tab1">笔记本</a></li>
									<li><a data-toggle="tab" href="#tab1">智能手机</a></li>
									<li><a data-toggle="tab" href="#tab1">相机</a></li>
									<li><a data-toggle="tab" href="#tab1">首饰</a></li>
								</ul>
							</div>
						</div>
					</div>
					<!-- /选择标题-->

					<!-- 产品点击开始 -->
					<div class="col-md-12 mainn mainn-raised">
						<div class="row">
							<div class="products-tabs">
								<!-- 点击-->
								<div id="tab1" class="tab-pane active">
									<div class="products-slick" data-nav="#slick-nav-1" >
									
									<?php
                    include 'db.php';
								
                    
					$product_query = "SELECT * FROM products,categories WHERE product_cat=cat_id AND product_id BETWEEN 70 AND 75";
                $run_query = mysqli_query($con,$product_query);
                if(mysqli_num_rows($run_query) > 0){

                    while($row = mysqli_fetch_array($run_query)){
                        $pro_id    = $row['product_id'];
                        $pro_cat   = $row['product_cat'];
                        $pro_brand = $row['product_brand'];
                        $pro_title = $row['product_title'];
                        $pro_price = $row['product_price'];
                        $pro_image = $row['product_image'];

                        $cat_name = $row["cat_title"];

                        echo "
				
                        
                                
								<div class='product'>
									<a href='product.php?p=$pro_id'><div class='product-img'>
										<img src='product_images/$pro_image' style='max-height: 170px;' alt=''>
										<div class='product-label'>
											<span class='sale'>-30%</span>
											<span class='new'>新</span>
										</div>
									</div></a>
									<div class='product-body'>
										<p class='product-category'>$cat_name</p>
										<h3 class='product-name header-cart-item-name'><a href='product.php?p=$pro_id'>$pro_title</a></h3>
										<h4 class='product-price header-cart-item-info'>$pro_price<del class='product-old-price'>990元</del></h4>
										<div class='product-rating'>
											<i class='fa fa-star'></i>
											<i class='fa fa-star'></i>
											<i class='fa fa-star'></i>
											<i class='fa fa-star'></i>
											<i class='fa fa-star'></i>
										</div>
										<div class='product-btns'>
											<button class='add-to-wishlist'><i class='fa fa-heart-o'></i><span class='tooltipp'>添加到愿望清单</span></button>
											<button class='add-to-compare'><i class='fa fa-exchange'></i><span class='tooltipp'>加入比较</span></button>
											<button class='quick-view'><i class='fa fa-eye'></i><span class='tooltipp'>快速预览商品</span></button>
										</div>
									</div>
									<div class='add-to-cart'>
										<button pid='$pro_id' id='product' class='add-to-cart-btn block2-btn-towishlist' href='#'><i class='fa fa-shopping-cart'></i>添加到购物车</button>
									</div>
								</div>
                               
							
                        
			";
		}
        ;
      
}
?>
										<!-- 产品-->
										
	
										<!-- /商品-->
										
										
										<!-- /商品 -->
									</div>
									<div id="slick-nav-1" class="products-slick-nav"></div>
								</div>
								<!-- /点击 -->
							</div>
						</div>
					</div>
					<!--商品点击 -->
				</div>
				<!-- /行 -->
			</div>
			<!-- /大的容器 -->
		</div>
		<!-- /学则-->

		<!-- 主要标签-->
		<div id="hot-deal" class="section mainn mainn-raised">
			<!-- 容器 -->
			<div class="container">
				<!-- 行 -->
				<div class="row">
					<div class="col-md-12">
						<div class="hot-deal">
							<ul class="hot-deal-countdown">
								<li>
									<div>
										<h3>02</h3>
										<span>天数</span>
									</div>
								</li>
								<li>
									<div>
										<h3>10</h3>
										<span>小时</span>
									</div>
								</li>
								<li>
									<div>
										<h3>34</h3>
										<span>分钟</span>
									</div>
								</li>
								<li>
									<div>
										<h3>60</h3>
										<span>秒</span>
									</div>
								</li>
							</ul>
							<h2 class="text-uppercase">这周热卖商品</h2>
							<p>新品优惠50%</p>
							<a class="primary-btn cta-btn" href="store.php">立即购物</a>
						</div>
					</div>
				</div>
				<!-- /行-->
			</div>
			<!-- /容器 -->
		</div>
		<!-- /开始热卖标签->
		

		<!-- 选择 -->
		<div class="section">
			<!-- 容器 -->
			<div class="container">
				<!-- 行-->
				<div class="row">

					<!-- 选择标签标题-->
					<div class="col-md-12">
						<div class="section-title">
							<h3 class="title">热销排行榜</h3>
							<div class="section-nav">
								<ul class="section-tab-nav tab-nav">
									<li class="active"><a data-toggle="tab" href="#tab2">正式上架商品</a></li>
									<li><a data-toggle="tab" href="#tab2">衬衫</a></li>
									<li><a data-toggle="tab" href="#tab2">T-Shirts</a></li>
									<li><a data-toggle="tab" href="#tab2">裤子</a></li>
								</ul>
							</div>
						</div>
					</div>
					<!-- /选择标题->

					<!-- 商品列表点击 -->
					<div class="col-md-12 mainn mainn-raised">
						<div class="row">
							<div class="products-tabs">
								<!-- 点击-->
								<div id="tab2" class="tab-pane fade in active">
									<div class="products-slick" data-nav="#slick-nav-2">
										<!-- 商品-->
										<?php
                    include 'db.php';
								
                    
					$product_query = "SELECT * FROM products,categories WHERE product_cat=cat_id AND product_id BETWEEN 59 AND 65";
                $run_query = mysqli_query($con,$product_query);
                if(mysqli_num_rows($run_query) > 0){

                    while($row = mysqli_fetch_array($run_query)){
                        $pro_id    = $row['product_id'];
                        $pro_cat   = $row['product_cat'];
                        $pro_brand = $row['product_brand'];
                        $pro_title = $row['product_title'];
                        $pro_price = $row['product_price'];
                        $pro_image = $row['product_image'];

                        $cat_name = $row["cat_title"];

                        echo "
				
                        
                                
								<div class='product'>
									<a href='product.php?p=$pro_id'><div class='product-img'>
										<img src='product_images/$pro_image' style='max-height: 170px;' alt=''>
										<div class='product-label'>
											<span class='sale'>-30%</span>
											<span class='new'>新</span>
										</div>
									</div></a>
									<div class='product-body'>
										<p class='product-category'>$cat_name</p>
										<h3 class='product-name header-cart-item-name'><a href='product.php?p=$pro_id'>$pro_title</a></h3>
										<h4 class='product-price header-cart-item-info'>$pro_price<del class='product-old-price'>99块</del></h4>
										<div class='product-rating'>
											<i class='fa fa-star'></i>
											<i class='fa fa-star'></i>
											<i class='fa fa-star'></i>
											<i class='fa fa-star'></i>
											<i class='fa fa-star'></i>
										</div>
										<div class='product-btns'>
											<button class='add-to-wishlist'><i class='fa fa-heart-o'></i><span class='tooltipp'>增加到愿望清单</span></button>
											<button class='add-to-compare'><i class='fa fa-exchange'></i><span class='tooltipp'>增加比较</span></button>
											<button class='quick-view'><i class='fa fa-eye'></i><span class='tooltipp'>快速预览</span></button>
										</div>
									</div>
									<div class='add-to-cart'>
										<button pid='$pro_id' id='product' class='add-to-cart-btn block2-btn-towishlist' href='#'><i class='fa fa-shopping-cart'></i> 增加到购物清单</button>
									</div>
								</div>
                               
							
                        
			";
		}
        ;
      
}
?>
										
										<!-- /商品-->
									</div>
									<div id="slick-nav-2" class="products-slick-nav"></div>
								</div>
								<!-- /点击-->
							</div>
						</div>
					</div>
					<!-- /商品点击 -->
				</div>
				<!-- /行 -->
			</div>
			<!-- /大的容器 -->
		</div>
		<!-- /选择 -->

		<!-- 选择-->
		<div class="section">
			<!-- 大的容器-->
			<div class="container">
				<!-- 行 -->
				<div class="row">
					<div class="col-md-4 col-xs-6">
						<div class="section-title">
							<h4 class="title">热销排行榜</h4>
							<div class="section-nav">
								<div id="slick-nav-3" class="products-slick-nav"></div>
							</div>
						</div>
						

						<div class="products-widget-slick" data-nav="#slick-nav-3">
							<div id="get_product_home">
								<!-- 商品组件 -->
								
								<!-- 商品组件-->
							</div>

							<div id="get_product_home2">
								<!-- 商品组件 -->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/product01.png" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">种类</p>
										<h3 class="product-name"><a href="#">商品开始将在这儿/a></h3>
										<h4 class="product-price">$980.00 <del class="product-old-price">99块</del></h4>
									</div>
								</div>
								<!-- /商品组件 -->

								<!-- 商品组件-->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/product02.png" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">种类</p>
										<h3 class="product-name"><a href="#">商品开始将在这儿</a></h3>
										<h4 class="product-price">94快 <del class="product-old-price">99块</del></h4>
									</div>
								</div>
								<!-- /商品组件 -->

								<!-- 商品组件 -->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/product03.png" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">种类</p>
										<h3 class="product-name"><a href="#">你的商品在这儿</a></h3>
										<h4 class="product-price">99块<del class="product-old-price">99块</del></h4>
									</div>
								</div>
								<!-- 商品组件 -->
							</div>
						</div>
					</div>

					<div class="col-md-4 col-xs-6">
						<div class="section-title">
							<h4 class="title">热销排行榜</h4>
							<div class="section-nav">
								<div id="slick-nav-4" class="products-slick-nav"></div>
							</div>
						</div>

						<div class="products-widget-slick" data-nav="#slick-nav-4">
							<div>
								<!-- 商品组件 -->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/product04.png" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">种类</p>
										<h3 class="product-name"><a href="#">你的商品在这儿</a></h3>
										<h4 class="product-price">99块<del class="product-old-price">9块</del></h4>
									</div>
								</div>
								<!-- /商品组件-->

								<!-- 商品组件 -->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/product05.png" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">种类</p>
										<h3 class="product-name"><a href="#">你的商品在这儿</a></h3>
										<h4 class="product-price">99块<del class="product-old-price">99块</del></h4>
									</div>
								</div>
								<!-- /商品组件 -->

								<!-- product widget -->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/product06.png" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">Category</p>
										<h3 class="product-name"><a href="#">你的商品在这儿/a></h3>
										<h4 class="product-price">98块 <del class="product-old-price">99块</del></h4>
									</div>
								</div>
								<!-- 商品组件-->
							</div>

							<div>
								<!-- 商品组件-->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/product07.png" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">种类</p>
										<h3 class="product-name"><a href="#">你的商品在这儿</a></h3>
										<h4 class="product-price">99块 <del class="product-old-price">99块</del></h4>
									</div>
								</div>
								<!-- /商品组件-->

								<!-- 商品组件 -->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/product08.png" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">种类</p>
										<h3 class="product-name"><a href="#">你的商品在这儿</a></h3>
										<h4 class="product-price">99块 <del class="product-old-price">99块</del></h4>
									</div>
								</div>
								<!-- /商品组件-->

								<!-- 商品组件 -->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/product09.png" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">种类</p>
										<h3 class="product-name"><a href="#">你的商品在这儿</a></h3>
										<h4 class="product-price">99块 <del class="product-old-price">99块</del></h4>
									</div>
								</div>
								<!-- 商品组件-->
							</div>
						</div>
					</div>

					<div class="clearfix visible-sm visible-xs">
					    
					</div>

					<div class="col-md-4 col-xs-6">
						<div class="section-title">
							<h4 class="title">热销排行榜</h4>
							<div class="section-nav">
								<div id="slick-nav-5" class="products-slick-nav"></div>
							</div>
						</div>

						<div class="products-widget-slick" data-nav="#slick-nav-5">
							<div>
								<!-- 商品组件 -->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/product01.png" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">种类</p>
										<h3 class="product-name"><a href="#">你的商品在这儿</a></h3>
										<h4 class="product-price">99块 <del class="product-old-price">99块</del></h4>
									</div>
								</div>
								<!-- /商品组件 -->

								<!-- 商品组件-->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/product02.png" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">种类</p>
										<h3 class="product-name"><a href="#">你的商品在这儿</a></h3>
										<h4 class="product-price">99块 <del class="product-old-price">99块</del></h4>
									</div>
								</div>
								<!-- /商品组件-->

								<!-- 商品组将-->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/product03.png" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">种类</p>
										<h3 class="product-name"><a href="#">你的商品在这儿</a></h3>
										<h4 class="product-price">99块 <del class="product-old-price">99块</del></h4>
									</div>
								</div>
								<!-- 商品组件-->
							</div>

							<div>
								<!-- 商品组件 -->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/product04.png" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">种类</p>
										<h3 class="product-name"><a href="#">你的商品在这儿</a></h3>
										<h4 class="product-price">99块<del class="product-old-price">99块</del></h4>
									</div>
								</div>
								<!-- /商品组件-->
								

								<!-- 商品组件 -->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/product05.png" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">种类</p>
										<h3 class="product-name"><a href="#">你的商品在这儿</a></h3>
										<h4 class="product-price">99块 <del class="product-old-price">99块</del></h4>
									</div>
								</div>
								<!-- /商品组件-->

								<!-- 商品组将-->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/product06.png" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">种类</p>
										<h3 class="product-name"><a href="#">你的商品在这儿</a></h3>
										<h4 class="product-price">99块 <del class="product-old-price">99块</del></h4>
									</div>
								</div>
								<!-- 商品组件-->
							</div>
						</div>
					</div>

				</div>

			</div>

		</div>
		<!-- /SECTION -->
</div>
		