<?php
//开始连接数据库
$conn=mysql_connect("localhost","root","");
//开始连接数据库表
mysql_select_db("ecommerce",$conn);
//开始将内容转换为中文字符
mysql_query("set names UTF8");
if(isset($_GET['id'])&&!empty($_GET['id']))
    $id=intval($_GET['id']);
$sql="select * from email_info where email_id=$id";
$result=mysql_query($sql);
$row=mysql_fetch_assoc($result);

?>

<html>
<meta charset="utf-8">
<body bgcolor="#f0ffff">
<p align="center">更新数据</p>

<form  method="post"  action="email_edit.php?id=<?php echo $row['email_id'];?>">
    <table border="1" align="center">
        <tr><th> <br>个人用户邮箱<input type="text" name="email" value="<?php echo$row['email'];?>"/>>*</br></th></tr>
        <tr><th><br><input type="submit" value="提交">*</br></th></tr>

    </table>
</form>

</body>
</html>