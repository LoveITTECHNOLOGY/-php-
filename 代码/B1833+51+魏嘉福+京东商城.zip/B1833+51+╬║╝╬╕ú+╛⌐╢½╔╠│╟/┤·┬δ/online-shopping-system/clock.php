<html>
<head>
    <title>时钟管理</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="./css/clock.css">
</head>
<body>

<div class="clock">
    <div class="hour">
        <div class="hr" id="hr"></div>
    </div>
    <div class="min">
        <div class="mn" id="mn"></div>
    </div>
    <div class="sec">
        <div class="sc" id="sc"></div>
    </div>
</div>
</body>
<script>
    const deg=6;
    const hr=document.querySelector('#hr');
    const mn=document.querySelector('#mn');
    const sc=document.querySelector('#sc');


    setInterval(()=>{
        let day=new Date();
    let hh=day.getHours()*30;
    let mm=day.getMinutes()*deg;
    let ss=day.getSeconds()*deg;
    hr.style.transform=`rotateZ(${hh+(mm/12)}deg)`;
    mn.style.transform=`rotateZ(${mm}deg)`;
    sc.style.transform=`rotateZ(${ss}deg)`;

    })



</script>
</html>
<html>
<head>
    <meta charset="UTF-8">
    <title>浏览计数器-ljccccccccccc@163.com</title>
</head>
<body>
<?php
//数字输出网页计数器
$max_len = 9;
$CounterFile = "counter.dat";
if(!file_exists($CounterFile)){  //如果计数器文件不存在
    $counter = 0;
    $cf = fopen($CounterFile,"w"); //打开文件
    fputs($cf,'0');     //初始化计数器
    fclose($cf);     //关闭文件
}
else{          //取回当前计数器的值
    $cf = fopen($CounterFile,"r");
    $counter = trim(fgets($cf,$max_len));
    fclose($cf);
}
$counter++;         //计数器加一
$cf = fopen($CounterFile,"w");    //写入新的数据
fputs($cf,$counter);
fclose($cf);
?>
<div id="dd"  class="p1welcome" align="center">
    <span>欢迎您!</p></span>
  <span>您是本站的第
      <?php
      echo $counter;       //输出计数器
      ?>
      位访客！</span>
</div>
<div class="info">
    <p>本网站创建于2020/4/27 所有的项目大小为20MB 最后修改时间为2020/4/39<br> 主要设计做一个京东在线网站，
    本网站的作者为:魏嘉福 制作时间为:2020/4/27
    版权声明: 互联网药品信息服务资格证编号(京)-经营性-2014-0008&nbsp京公网安备 11000002000088号<br>
    版权所有禁止盗取网站的个人信息<br></p>
</div>
</body>
</html>



