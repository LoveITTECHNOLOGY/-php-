<html>
<head>
    <link rel="stylesheet" href="../css/transform.css">
    <title>this</title>
    <meta charset="utf-8">
</head>
<html>
<head>
    <title>smoke</title>
    <link rel="stylesheet" href="../css/style1.css">
</head>
<body>
<section>
    <video src="../video/smoke.mp4" autoplay muted></video>
    <h1>

        <span>L</span>
        <span>I</span>
        <span>F</span>
        <span>E</span>
        <span>请</span>
        <span><a href="manageuser.php">返回</a></span>
        <span>页</span>
        <span>面</span>
    </h1>
</section>
</body>
</html>
<body >

<!--开始写对购物网站信息的查询-->
<div class="search1">
    <a href="../search1.php" class="search1"><i class="fas fa-search">用户信息查询</i></a>
</div>
<!--开始产品信息进行管理-->
<div class="product1">
    <a href="../product1.php" class="product_1"><i class="fab fa-y-combinator">商品信息管理</i></a>
</div>
<!--开始实现对管理员的管理-->
<div class="admin1">
    <a href="../admin_manage.php" class="admin_1"><i class="fas fa-user-lock">管理员管理</i></a>
</div>
<!--开始实现对个人邮件的管理-->
<div class="email_manage">
    <a href="../email_manage.php" class=email_manage_1><i class="fas fa-envelope">用户邮件管理</i></a>
</div>
<!--实现对文件大小的采集-->
<div class="file_manage">
    <a href="../file_manage.php" class="file_manage"><i class="fas fa-file-word">文件信息查询</i></a>
</div>
</body>
</html>