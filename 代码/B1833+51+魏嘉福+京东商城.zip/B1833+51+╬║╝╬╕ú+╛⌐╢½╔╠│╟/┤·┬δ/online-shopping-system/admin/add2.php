<?php

//开始连接数据库
$conn=mysql_connect("localhost","root","");
//开始查询数据库
mysql_select_db("ecommerce",$conn);
//开始将查询的内容设置成中文
mysql_query("set names 'UTF8'");
//开始传值
$first_name=$_POST['first_name'];
$last_name=$_POST['last_name'];
$email=$_POST['email'];
$mobile=$_POST['mobile'];
$password=$_POST['password'];
$address1=$_POST['address1'];
$address2=$_POST['address2'];
//开始插入内容
mysql_query("insert into user_info(user_id,first_name,password,last_name,email,mobile,address1,address2)
VALUES ('".$user_id."','".$first_name."','".$password."','".$last_name."','".$email."','".$mobile."','".$address1."','".$address2."')");
//开始返回主页面
header("location:manageuser.php");
?>