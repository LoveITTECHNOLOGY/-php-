

        

        <div id="newsletter" class="section">
			<!-- 容器 -->
			<div class="container">
				<!-- 行-->
				<div class="row">
					<div class="col-md-12">
					
						<div class="newsletter">
							<p>报名参加<strong>优惠更新</strong></p>
							<form id="offer_form" onsubmit="return false">
								<input class="input" type="email" id="email" name="email" placeholder="输入你的邮箱">
								<button class="newsletter-btn" value="注册" name="signup_button" type="submit"><i class="fa fa-envelope"></i> 订阅</button>
							</form>
							<div class="" id="offer_msg">

                            </div>
							<ul class="newsletter-follow">
								<li>
									<a href="#"><i class="fab fa-qq"></i></a>
								</li>
								<li>
									<a href="#"><i class="fab fa-weixin"></i></a>
								</li>
								<li>
									<a href="#"><i class="fas fa-tv"></i></i></a>
								</li>
								
							</ul>
						</div>
					</div>
				</div>
				<!-- /行 -->
			</div>
			<!-- /容器 -->
		</div>