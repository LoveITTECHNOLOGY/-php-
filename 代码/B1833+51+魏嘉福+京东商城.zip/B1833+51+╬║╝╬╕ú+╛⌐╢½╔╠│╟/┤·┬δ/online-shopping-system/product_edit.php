<?php
/**
 * Created by PhpStorm.
 * User: administer
 * Date: 2020/3/19
 * Time: 14:46
 */
//开始连接数据库
$conn=mysql_connect("localhost","root","");
//开始连接数据库表
mysql_select_db("ecommerce",$conn);
//开始将内容转换为中文字符
mysql_query("set names UTF8");
$id=intval($_GET['id']);
$product_brand=$_POST['product_brand'];
$product_title=$_POST['product_title'];
$product_price=$_POST['product_price'];
$product_image=$_POST['product_image'];
$product_desc=$_POST['product_desc'];
$sql="update products set product_brand='$product_brand',product_title='$product_title',product_price='$product_price',
product_image='$product_image',product_desc='$product_desc' where product_id=".$id;
$r=mysql_query($sql);
if($r)
    echo "<script>alert('修改成功');
location.href='product1.php';</script>";
?>
<html>
<meta charset="utf-8">
</html>