<?php
include "db.php";
mysql_query("set names 'UTF8'");

session_start();

//登录脚本从这里开始
//如果给定凭据的用户与数据库中的可用数据成功匹配，则我们将回显字符串login_success
#login_success字符串将返回到匿名功能$（“＃login”）。click（）
if(isset($_POST["email"]) && isset($_POST["password"])){
	$email = mysqli_real_escape_string($con,$_POST["email"]);
	$password = $_POST["password"];
	$sql = "SELECT * FROM user_info WHERE email = '$email' AND password = '$password'";
	$run_query = mysqli_query($con,$sql);
	$count = mysqli_num_rows($run_query);
    $row = mysqli_fetch_array($run_query);
		$_SESSION["uid"] = $row["user_id"];
		$_SESSION["name"] = $row["first_name"];
		$ip_add = getenv("REMOTE_ADDR");
    //我们已经在login_form.php页面中创建了一个cookie，因此如果该cookie可用，则表示用户未登录
    //        
//如果用户记录在数据库中可用，则$ count等于1
	if($count == 1){
		   	
			if (isset($_COOKIE["product_list"])) {
				$p_list = stripcslashes($_COOKIE["product_list"]);
                //这里我们将存储的json产品列表cookie解码为普通数组
				$product_list = json_decode($p_list,true);
				for ($i=0; $i < count($product_list); $i++) {
                    //从数据库中获取用户ID后，我们将检查用户购物车项目，是否已列出产品
					$verify_cart = "SELECT id FROM cart WHERE user_id = $_SESSION[uid] AND p_id = ".$product_list[$i];
					$result  = mysqli_query($con,$verify_cart);
					if(mysqli_num_rows($result) < 1){
                        //如果用户将首次购买的产品添加到购物车中，我们将使用有效ID将user_id更新到数据库表中
						$update_cart = "UPDATE cart SET user_id = '$_SESSION[uid]' WHERE ip_add = '$ip_add' AND user_id = -1";
						mysqli_query($con,$update_cart);
					}else{
                        //如果该产品已经存在于数据库表中，我们将删除该记录
						$delete_existing_product = "DELETE FROM cart WHERE user_id = -1 AND ip_add = '$ip_add' AND p_id = ".$product_list[$i];
						mysqli_query($con,$delete_existing_product);
					}
				}
                //这里我们要销毁用户cookie
				setcookie("product_list","",strtotime("-1 day"),"/");
                //如果用户从购物车页面后登录，我们将发送cart_login
				echo "cart_login";
				
				
				exit();
				
			}
        //如果用户是从页面登录，我们将发送login_success
			echo "登录成功!";
			$BackToMyPage = $_SERVER['HTTP_REFERER'];
				if(!isset($BackToMyPage)) {
					header('Location: '.$BackToMyPage);
					echo"<script type='text/javascript'>
					
					</script>";
				} else {
					header('Location: index.php'); //默认页面
				} 
				
			
            exit;

		}else{
                $email = mysqli_real_escape_string($con,$_POST["email"]);
                $password =md5($_POST["password"]) ;
                $sql = "SELECT * FROM admin_info WHERE admin_email = '$email' AND admin_password = '$password'";
                $run_query = mysqli_query($con,$sql);
                $count = mysqli_num_rows($run_query);

        //如果用户记录在数据库中可用，则$ count等于1
            if($count == 1){
                $row = mysqli_fetch_array($run_query);
                $_SESSION["uid"] = $row["admin_id"];
                $_SESSION["name"] = $row["admin_name"];
                $ip_add = getenv("REMOTE_ADDR");
                //我们已经在login_form.php页面中创建了一个cookie，因此如果该cookie可用，则表示用户未登录

                //如果用户是从页面登录，我们将发送login_success
                echo "注册成功！请登录";

                    echo "<script> location.href='admin/addproduct.php'; </script>";
                    exit;

                }else{
                    echo "<span style='color:red;'>登录前请先注册..！</span>";
                    exit();
                }
    
	
}
    
	
}

?>