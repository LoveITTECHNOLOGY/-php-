<?php
//开始连接数据库
$conn=mysql_connect("localhost","root","");
//开始连接数据库表
mysql_select_db("ecommerce",$conn);
//开始将内容转换为中文字符
mysql_query("set names UTF8");
if(isset($_GET['id'])&&!empty($_GET['id']))
    $id=intval($_GET['id']);
$sql="select * from products where product_id=$id";
$result=mysql_query($sql);
$row=mysql_fetch_assoc($result);

?>

<html>
<meta charset="utf-8">
<body bgcolor="#f0ffff">
<p align="center">更新数据</p>

<form  method="post"  action="product_edit.php?id=<?php echo $row['product_id'];?>">
    <table border="1" align="center">
        <tr><th>商品品牌<input type="text" name="product_brand" value="<?php echo$row['product_brand'];?>"/>*</th></tr>
        <tr><th> <br>商品标题<input type="text" name="product_title" value="<?php echo$row['product_title'];?>"/>>*</br></th></tr>
        <tr><th><br>商品价格<input type="text" name="product_price" value="<?php echo $row['product_price'];?>"/>*</br></th></tr>
        <tr><th><br>商品图片<input type="file" name="product_image" value="<?php echo $row['product_image'];?>"/>*</br></th></tr>
        <tr><th><br>商品描述<textarea rows="4" cols="30" name="product_desc"  ><?php echo$row['product_desc'];?></textarea></br></th></tr>
        <tr><th><br><input type="submit" value="提交">*</br></th></tr>

    </table>
</form>

</body>
</html>