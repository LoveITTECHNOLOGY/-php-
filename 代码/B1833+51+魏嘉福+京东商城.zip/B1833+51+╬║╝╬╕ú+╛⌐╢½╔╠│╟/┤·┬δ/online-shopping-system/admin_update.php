<?php
//开始连接数据库
$conn=mysql_connect("localhost","root","");
//开始连接数据库表
mysql_select_db("ecommerce",$conn);
//开始将内容转换为中文字符
mysql_query("set names UTF8");
if(isset($_GET['id'])&&!empty($_GET['id']))
    $id=intval($_GET['id']);
$sql="select * from admin_info where admin_id=$id";
$result=mysql_query($sql);
$row=mysql_fetch_assoc($result);

?>

<html>
<meta charset="utf-8">
<body bgcolor="#f0ffff">
<p align="center">更新数据</p>

<form  method="post"  action="admin_edit.php?id=<?php echo $row['admin_id'];?>">
    <table border="1" align="center">
        <tr><th>管理员<input type="text" name="admin_name" value="<?php echo$row['admin_name'];?>"/>*</th></tr>
        <tr><th> <br>管理员邮箱<input type="text" name="admin_email" value="<?php echo$row['admin_email'];?>"/>>*</br></th></tr>
        <tr><th><br>管理员密码<input type="text" name="admin_password" value="<?php echo $row['admin_password'];?>"/>*</br></th></tr>
        <tr><th><br><input type="submit" value="提交">*</br></th></tr>

    </table>
</form>

</body>
</html>