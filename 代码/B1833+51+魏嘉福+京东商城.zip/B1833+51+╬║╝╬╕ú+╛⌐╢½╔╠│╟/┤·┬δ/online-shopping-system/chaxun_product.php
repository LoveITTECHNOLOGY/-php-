<html><body>
<h3 align="center">用户查询结果</h3>
<meta charset="UTF-8">
<link rel="stylesheet" href="./css/user_chaxun.css">

<?php
//开始连接数据库
$conn=mysql_connect("localhost","root","");
//开始查询数据表名
mysql_select_db("ecommerce",$conn);
//开始将连接表名设置为中文字符
mysql_query("set names 'UTF8'");
require('func_page_product.php');
$PageSize=7;
if(isset($_GET['Page'])&&(int)$_GET['Page']>0)
    $page=$_GET['Page'];
else $page=1;
$keyword=$_GET['keyword'];
$sel=trim($_GET['sel']);
//实现对购物用户的查询
//echo $keyword.$sel;
$sql="select * from products ";
if($keyword<>"")
    if($sel=='age')
        $sql=$sql." where $sel>$keyword";
    else
        $sql=$sql."where $sel like '%$keyword%'";
//echo $sql;a
$result=mysql_query($sql);
$t=mysql_num_rows($result);
$RecordCount=$t;
//$PageCount=ceil($RecordCount/$PageSize);
//mysql_free_result($result);
//$result=mysql_query("select * from user where $sel like '%$keyword%' limit ". ($page-1)*$PageSize.",".$PageSize,$conn);
if($t>0){
    echo "<p>关键字为：".$keyword.",共找到".$t."条记录</p>";
}
?>

<table border="1" width="95%" align="center" class="table2">
    <tr>
        <th>序号</th>
        <th>产品品牌</th>
        <th>产品名称</th>
        <th>产品价格</th>
        <th>产品描述</th>
        <th>删除</th>
        <th>操作</th>
    </tr>
    <?PHP
    mysql_data_seek($result,($page-1)*$PageSize);
    for($i=0;$i<$PageSize;$i++){
        $row=mysql_fetch_assoc($result);
        if($row)
        {?>
    <tr>
        <td><?php echo $row['product_id'];?></td>
        <td><?php echo $row['product_brand'];?></td>
        <td><?php echo $row['product_title'];?></td>
        <td><?php echo $row['product_price'];?></td>
        <td><?php echo $row['product_desc'];?></td>
        </tr>

        <?php }}
    mysql_free_result($result)
    ?>
</table>

<h3> <a href="product1.php">返回</a> </h3>

<?php
$url=$_SERVER["PHP_SELF"];
page($RecordCount,$PageSize,$page,$url,$keyword,$sel);
?>
</body></html>