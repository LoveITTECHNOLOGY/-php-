
<?php
function page($RecordCount,$PageSize,$Page,$url,$keyword,$sel){
$PageCount=ceil($RecordCount/$PageSize);//总页数
$page_previous=($Page<=1)?1:$Page-1;//计算上一页的页数
$page_next=($Page>=$PageCount)?$PageCount:$Page+1;//计算下一页的页数
$page_start=($Page-5>0)?$Page-5:0;//只显示本页的前5页的页面链接
//后5页的页面链接
$page_end=($page_start+10<$PageCount)?$page_start+10:$PageCount;
$page_start=$page_end-10;
if($page_start<0)$page_start=0;//若当前页不合法，更正
$parse_url=parse_url($url);//判断url中是否含有字符串
if(empty($parse_url['query']))
    $url=$url.'?';//若不存，在url后添加?
else
    $url=$url.'&';//若存在，在后面添加&
if(empty($keyword)){
    if($Page==1)
        $str="[首页][上一页]";
    else
        $str="<a href='?Page=1'>[首页]</a><a href=".$url."Page=$page_previous>上一页</a>";
    for($i=$page_start;$i<$page_end;$i++){//输出页码链接
        $j=$i+1;
        if($j==$Page) $str=$str."$j  ";
        else
            $str=$str."<a href='".$url."Page=$j'>$j</a>";

    }
    if($Page==$PageCount)
        $str=$str."[下一页][末页]";
    else
        $str=$str."<a href=".$url."Page=$page_next>[下一页]</a>
            <a href=".$url."Page=$PageCount>[末页]</a>";
    $str=$str." &nbsp;共".$RecordCount."条记录 &nbsp;
        $Page/$PageCount 页";

}
else{
    $keyword=$_GET["keyword"];
    $sel=$_GET['sel'];
    $str="<a href=".$url."keyword=$keyword&sel=$sel&Page=$page_previous
        >上一页</a>";
    for($i=$page_start;$i<$page_end;$i++) {
        $j = $i + 1;
        $str = $str . "<a href='" . $url . "keyword=$keyword&sel=$sel&Page=$j'>$j</a>";
    }
    $str=$str."<a href=".$url."keyword=$keyword&sel=$sel&Page=$page_next>下一页</a>";
    $str=$str." &nbsp;共".$RecordCount."条记录 &nbsp;
        $Page/$PageCount 页";

}
?>
<p align="center">
    <?php
    echo $str;
    }?>
</p>