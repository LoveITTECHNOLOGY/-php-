<?php

//开始连接数据库
$conn=mysql_connect("localhost","root","");
//开始查询数据库
mysql_select_db("ecommerce",$conn);
//开始将查询的内容设置成中文
mysql_query("set names 'UTF8'");
//开始传值
$email=$_POST['email'];

//开始插入内容
mysql_query("insert into email_info(email)
VALUES ('".$email."')");
//开始返回主页面
header("location:email_manage.php");
?>