<?php

//开始连接数据库
$conn=mysql_connect("localhost","root","");
//开始查询数据库
mysql_select_db("ecommerce",$conn);
//开始将查询的内容设置成中文
mysql_query("set names 'UTF8'");
//开始传值
$admin_name=$_POST['admin_name'];
$admin_email=$_POST['admin_email'];
$admin_password=$_POST['admin_password'];

//开始插入内容
mysql_query("insert into admin_info(admin_name,admin_email,admin_password)
VALUES ('".$admin_name."','".$admin_email."','".$admin_password."')");
//开始返回主页面
header("location:admin_manage.php");
?>