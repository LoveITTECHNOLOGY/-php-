<?php

session_start();

unset($_SESSION["uid"]);

unset($_SESSION["name"]);
mysql_query("set names 'UTF8'");

$BackToMyPage = $_SERVER['HTTP_REFERER'];
if(isset($BackToMyPage)) {
    header('Location: '.$BackToMyPage);
} else {
    header('Location: index.php'); // 返回首页
}
   

?>
