<html>
<meta charset="UTF-8">
<body bgcolor="#f0ffff">
<p align="center">请填写个人信息</p>

<form action="product_check.php" method="post">
    <table border="1" align="center">
        <tr><th>商品品牌<input type="text" name="product_brand">*</th></tr>
        <tr><th> <br>商品标题<input type="text" name="product_title">*</br></th></tr>
        <tr><th><br>商品价格<input type="text" name="product_price">*</br></th></tr>
        <tr><th> <br>产品图片<input type="file" name="product_image">*</br></th></tr>
        <tr><th><br>商品描述<br><textarea rows="4" cols="30"  name="product_desc">*</textarea></br></th></tr>
        <tr><th><br><input type="submit" value="提交">*</br></th></tr>



    </table>
</form>

</body>
</html>